# Release Notes

## Poppy Humanoid 1.0.2
- official support for Odroid XU4
- updated documentation

## Poppy Humanoid 1.0.0
- support for Odroid U3
