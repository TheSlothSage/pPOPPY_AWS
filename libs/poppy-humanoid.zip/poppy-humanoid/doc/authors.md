# The Core Poppy Team

* [Matthieu Lapeyre](//github.com/matthieu-lapeyre) - Designer
* [Pierre Rouanet](//github.com/pierre-rouanet) - Developer
* [Pierre Yves Oudeyer](www.pyoudeyer.com) - PM
* [Jonathan Grizou](//github.com/jgrizou) - Developer
* [Nicolas Rabault](//github.com/nicolas-rabault) - Developer
* [Theo Segonds](//github.com/show0k) - Developer
* [Damien Caselli](//github.com/damiencaselli) - Developer

### Special Thanks To

* [Steve N'Guyen](//github.com/SteveNguyen) - Post Doc
* [Alexandre Le Falher](//github.com/Alexandre-lefalher) - Intern
* [Nicolas Saugnier](//github.com/Xevel) - Developer
* Brice Miard - Pétanque master

*For a more detailed list of the many individuals that contributed to the design and development of Poppy outside of GitHub, please refer to [the official Poppy project website](https://www.poppy-project.org/people/).*
*For a list of people who have contributed to the codebase, see [GitHub's list of contributors](http://github.com/poppy-project/poppy-humanoid/graphs/contributors).*
