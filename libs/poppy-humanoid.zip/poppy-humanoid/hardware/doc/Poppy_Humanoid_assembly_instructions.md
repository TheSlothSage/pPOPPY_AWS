# Poppy Humanoid assembly instructions

[**English instructions**](en/assemblyGuide.md)


[**Instructions en français**](fr/guideAssemblage.md)



