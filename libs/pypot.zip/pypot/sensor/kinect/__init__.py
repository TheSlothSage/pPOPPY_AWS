try:
    from .sensor import KinectSensor
except ImportError:
    pass
