try:
    from .arduino_sensor import ArduinoSensor

except ImportError:
    pass
